// Funções genericas
//Desenvolvedor : Valdir Ferreira Gomes da Silva

//Nome Função : Validar
//Objetivo    : Quantidade minima do CPF
function Validar() {
    var num = document.getElementById('cpf').value;
    if (num.length < 14) {
        alert('Quantidade invalida!');
    }
}

//Nome Função : Enum
//Objetivo    : Somente permitir que digite números
function Enum(num) {
    if (document.all)
        var tecla = event.keyCode;
    else if (document.layers)
        var tecla = num.which;
    if (tecla > 47 && tecla < 58)
        return true;
    else {
        if (tecla != 8)
            event.keyCode = 0;
        else
            return true;
    }
}

//Nome Função : Enumero
//Objetivo    : Somente permitir que digite números ( new ) Funciona
 function Enumero(e) {
            var tecla = (window.event) ? event.keyCode : e.which;
            if ((tecla > 47 && tecla < 58)) return true;
            else {
                if (tecla == 8 || tecla == 0) return true;
                else return false;
            }
        }

//Nome Função : MascaraCPF
//Objetivo    : Incluir mascara de CPF nos campos
function MascaraCPF(campo, teclaPress) {
    if (window.event) {
        var tecla = teclaPress.keyCode;
    } else {
        tecla = teclaPress.which;
    }
    var s = new String(campo.value);

    tam = s.length + 1;
    if (tam == 4)
        campo.value = s.substr(0, 4) + '.';

    if (tam == 8)
        campo.value = s.substr(0, 8) + '.';

    if (tam == 12)
        campo.value = s.substr(0, 12) + '-';
}

//Nome Função : MascaraCEP
//Objetivo    : Incluir mascara de CEP nos campos
function MascaraCEP(campo, teclaPress) {
    if (window.event) {
        var tecla = teclaPress.keyCode;
    } else {
        tecla = teclaPress.which;
    }
    var s = new String(campo.value);

    tam = s.length + 1;
    if (tam == 6)
        campo.value = s.substr(0, 6) + '-';

}

//Nome Função : Mascaratelefone
//Objetivo    : Incluir Mascara de telefone nos campos ex:(xx)xxxx-xxxx
function MascaraTelefone(Campo, teclaPress) {

    if (window.event) {
        var tecla = teclaPress.keyCode;
    } else {
        tecla = teclaPress.which;
    }

    var sub = new String(Campo.value);
    tamanho = sub.length + 1;

    if (tamanho == 2)
        Campo.value = '(' + sub.substr(0, 2);

    if (tamanho == 4)
        Campo.value = sub.substr(0, 4) + ')';

    if (tamanho == 9)
        Campo.value = sub.substr(0, 9) + '-';

}

//Nome Função : Valores
//Objetivo    : Incluir virgula em um campo formato moeda
function valores(Campo, teclaPress) {
    if (window.event) {
        var tecla = teclaPress.keyCode;
    } else {
        tecla = teclaPress.which;
    }

    var sub = new String(Campo.value);
    tamanho = sub.length + 1;

    if (tamanho == 3)
        Campo.value = sub.substr(0, 3) + ',';

}

//Nome Função : mascaraHora
//Objetivo    : Incluir Formato de hora nos campos
function MascaraHora(Campo, teclaPress) {
    if (window.event) {
        var tecla = teclaPress.keyCode;
    } else {
        tecla = teclaPress.which;
    }

    var sub = new String(Campo.value);
    tamanho = sub.length + 1;

    if (tamanho == 3)
        Campo.value = sub.substr(0, 3) + ':';
}

//Nome Função : validaHoraFinal
//Objetivo    : Validar dois campos - 
//         Ex : Verificar se o primeiro campo que e obrigatorio foi digitado para liberação do segundo campo
function validaHoraFinal(teclaPress) {
    var horaInicio = document.getElementById('horaInicio').value;
    if (horaInicio == null || horaInicio == '') {
        event.keyCode = 0;
        alert('Hora inicio deve ser digitada');
        return false;
    }

    if (document.all)
        var tecla = event.keyCode;
    else if (document.layers)
        var tecla = num.which;
    if (tecla > 47 && tecla < 58)
        return true;
    else {
        if (tecla != 8)
            event.keyCode = 0;
        else
            return true;
    }

}

//Nome Função : ChangeColorFocus
//Objetivo    : Mudacor quando estiver no focu
function ChangeColorFocus(obj, evt) {
    if (evt.type == "focus")
        obj.style.background = "#fff7b2";
    else if (evt.type == "blur")
        obj.style.background = "#ffffff";

}

//Nome função : Mascara descrição de campo
//Objetivo    : Colocar mascara Digite aqui 
function MascaraDescricao(obj, evt) {


    if (evt.type == "focus") {
        if (obj.value == "Digite aqui") {
            var sub = new String(obj.value);
            obj.value = sub.substr(0, 0) + '';
        }
    }

    else
        if (evt.type == "blur") {
            if (obj.value == "") {
                var sub = new String(obj.value);
                obj.value = sub.substr(0, 0) + 'Digite aqui';
            }
        }
}



//Nome função : mascara descrição de campo com Jquery
//Objetivo    : Colocar mascara digite aqui com Jquery
jQuery(document).ready(function () {

    //recuperando todos os inputs que tenham um atributo data-marcadagua.
    var inputs = $('*[data-marcadagua]')

    //tratando CADA input recuperado na linha acima.
    jQuery.each(inputs, function () {

        //se o input atual não tem valor, então aplica a marca d' água
        if (jQuery.trim($(this).val()) == '') {
            aplicaMarca($(this));

        }

        //adicionando os manipuladores para os eventos de entrada e saída em cada input.
        $(this).bind('focusin',
								function () {
								    //revomendo a marca d' água quando o input ganha o foco.
								    if ($(this).val() == $(this).attr('data-marcadagua')) {
								        limpaMarca($(this))
								    }
								}
						);
        $(this).bind('focusout',
								function () {
								    //aplicando a marca d' água quando o input perde o foco e não tem valor.
								    if (jQuery.trim($(this).val()) == '') {
								        aplicaMarca($(this));
								    }
								}
					   );

    });


    function aplicaMarca(input) {
        input.css('font-style', 'italic');
        input.css('color', '#666');
        input.val(input.attr('data-marcadagua'));
    }

    function limpaMarca(input) {
        input.css('font-style', '');
        input.css('color', '');
        input.val('');
    }


      

});


function mascaraMutuario(o, f) {
    v_obj = o
    v_fun = f
    setTimeout('execmascara()', 1)
}

function execmascara() {
    v_obj.value = v_fun(v_obj.value)
}

function cpfCnpj(v) {

    //Remove tudo o que não é dígito
    v = v.replace(/\D/g, "")

    if (v.length <= 14) { //CPF

        //Coloca um ponto entre o terceiro e o quarto dígitos
        v = v.replace(/(\d{3})(\d)/, "$1.$2")

        //Coloca um ponto entre o terceiro e o quarto dígitos
        //de novo (para o segundo bloco de números)
        v = v.replace(/(\d{3})(\d)/, "$1.$2")

        //Coloca um hífen entre o terceiro e o quarto dígitos
        v = v.replace(/(\d{3})(\d{1,2})$/, "$1-$2")

    } else { //CNPJ

        //Coloca ponto entre o segundo e o terceiro dígitos
        v = v.replace(/^(\d{2})(\d)/, "$1.$2")

        //Coloca ponto entre o quinto e o sexto dígitos
        v = v.replace(/^(\d{2})\.(\d{3})(\d)/, "$1.$2.$3")

        //Coloca uma barra entre o oitavo e o nono dígitos
        v = v.replace(/\.(\d{3})(\d)/, ".$1/$2")

        //Coloca um hífen depois do bloco de quatro dígitos
        v = v.replace(/(\d{4})(\d)/, "$1-$2")

    }

    return v

}




